// function updateCounter(){
//     let counter = 0
//     if(counter<500){
//         counter += 1
//         console.log(counter)
//     }
// }
// updateCounter();
// let counter = 0

for(i=0;i<=200;i++){
    
    console.log(i)
}